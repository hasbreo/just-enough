const {test} = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
function fixture() {
  const data={},session={},badges=[]; let listener;
  const storage = obj=>({get:async key=>({[key]:obj[key]}),set:async values=>Object.assign(obj,structuredClone(values)),remove:async key=>{delete obj[key];}});
  const chrome={
    storage:{local:storage(data),session:storage(session)},
    runtime:{getURL:p=>'chrome-extension://test-id/'+p,onMessage:{addListener:fn=>{listener=fn;}}},
    tabs:{query:async()=>[{id:7,url:'https://news.example/article'}],onRemoved:{addListener(){}},onUpdated:{addListener(){}}},
    action:{setBadgeText:async b=>{badges.push(b);},setBadgeBackgroundColor:async()=>{}}
  };
  const bgPath=fs.existsSync(path.join(__dirname,'../background.js'))?'../background.js':'../extension/background.js';
  vm.runInNewContext(fs.readFileSync(path.join(__dirname,bgPath),'utf8'),{chrome,URL,Date});
  return {data,session,badges,send:(message,sender={url:'chrome-extension://test-id/popup.html'})=>new Promise(resolve=>listener(message,sender,resolve))};
}
test('uses the top tab hostname for iframe permission checks',async()=>{
  const f=fixture();
  await f.send({type:'setSite',value:false});
  const result=await f.send({type:'canRun'},{url:'https://consent.vendor.example/',tab:{id:7,url:'https://news.example/article'}});
  assert.equal(result.allowed,false);
});
test('global disable applies to every page and can be reenabled',async()=>{
  const f=fixture(),sender={tab:{id:7,url:'https://news.example/'}};
  assert.equal((await f.send({type:'canRun'},sender)).allowed,true);
  await f.send({type:'setEnabled',value:false});
  assert.equal((await f.send({type:'canRun'},sender)).allowed,false);
  await f.send({type:'setEnabled',value:true});
  assert.equal((await f.send({type:'canRun'},sender)).allowed,true);
});
test('content scripts cannot edit settings',async()=>{
  const f=fixture();
  assert.ok((await f.send({type:'setEnabled',value:false},{url:'https://news.example/',tab:{id:7,url:'https://news.example/'}})).error);
  assert.equal(f.data.settings,undefined);
});
test('simultaneous settings changes do not lose updates',async()=>{
  const f=fixture();
  await Promise.all([f.send({type:'setEnabled',value:false}),f.send({type:'setSite',value:false})]);
  assert.equal(f.data.settings.enabled,false); assert.deepEqual(f.data.settings.excludedHosts,['news.example']);
});
test('rejects unknown or restricted page contexts',async()=>{
  const f=fixture();
  for(const url of ['chrome://extensions','file:///tmp/demo.html','about:blank','invalid']){
    assert.equal((await f.send({type:'canRun'},{tab:{id:7,url}})).allowed,false);
  }
});
test('stores only tab attempt kind and timestamp in session, without URLs or page text',async()=>{
  const f=fixture();
  await f.send({type:'recordAction',kind:'reject',label:'private page text'},{tab:{id:7,url:'https://news.example/article'}});
  assert.equal(f.session['tab:7'].kind,'reject');
  assert.deepEqual(Object.keys(f.session['tab:7']),['kind','at']);
  assert.equal(f.data.settings,undefined); assert.equal(f.badges[0].text,'✓');
});
test('pause prevents recording a consent attempt',async()=>{
  const f=fixture(); await f.send({type:'setEnabled',value:false});
  const result=await f.send({type:'recordAction',kind:'save'},{tab:{id:7,url:'https://news.example/'}});
  assert.equal(result.ok,false); assert.deepEqual(f.session,{});
});
