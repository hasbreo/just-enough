const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {JSDOM} = require('jsdom');
const enginePath = fs.existsSync(path.join(__dirname,'../engine.js')) ? '../engine.js' : '../extension/engine.js';
const source = fs.readFileSync(path.join(__dirname, enginePath), 'utf8');

// jsdom provides the real DOM/selector/event model; geometry is supplied because
// it has no rendering engine. These are simulated-layout tests, not Chrome tests.
function fixture(html) {
  const dom = new JSDOM(html, {runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://fixture.example/'});
  const w = dom.window;
  let now = 100000;
  w.Date.now = () => now;
  Object.defineProperty(w.HTMLElement.prototype, 'innerText', {get() {return this.textContent;}});
  w.Element.prototype.getClientRects = function() {return this.isConnected ? [this.getBoundingClientRect()] : [];};
  w.Element.prototype.getBoundingClientRect = function() {
    const top = this.hasAttribute('data-offscreen') ? 2000 : 20;
    return {x:20, y:top, left:20, top, right:320, bottom:top+100, width:300, height:100};
  };
  const getStyle = w.getComputedStyle.bind(w);
  w.getComputedStyle = el => new Proxy(getStyle(el), {get(target, key) {
    if (key === 'opacity') return target.opacity || '1';
    return Reflect.get(target, key);
  }});
  w.eval(source);
  const engine = new w.JustEnough.Engine();
  const clicked = [];
  w.document.addEventListener('click', e => clicked.push(e.target.id || e.target.textContent.trim()));
  return {w, engine, clicked, step(ms=1000) {now+=ms; const action=engine.next(); if(action?.element) engine.perform(action); return action;}, close() {dom.window.close();}};
}
const banner = body => `<section role="dialog"><p>We use cookies to improve your experience.</p>${body}</section>`;
for (const choice of ['Reject all', 'Reject optional cookies', 'Necessary cookies only', 'Accept only necessary cookies', 'Accept essential only', 'Continue without accepting', 'Decline all', 'No thanks']) {
  test(`chooses ${choice} instead of accept all`, () => {
    const f = fixture(banner(`<button id="all">Accept all</button><button id="safe">${choice}</button>`));
    assert.equal(f.step()?.kind, 'reject');
    assert.deepEqual(f.clicked, ['safe']); f.close();
  });
}
for (const unsafe of ['Accept all', 'Accept', 'OK', 'Agree', 'Continue', 'Close', 'Accept necessary and marketing cookies', 'Accept recommended', 'Reject all and subscribe', 'Save preferences']) {
  test(`does not guess at ${unsafe}`, () => {
    const f=fixture(banner(`<button>${unsafe}</button>`));
    assert.equal(f.step(), null); assert.deepEqual(f.clicked, []); f.close();
  });
}
test('does not act on a normal page, transaction, or inline cookie-policy article', () => {
  const f=fixture('<h1>Cookie policy</h1><button>Reject</button><article id="cookies">We use cookies.<button>Reject all</button></article><div role="dialog">Reject payment?<button>Reject</button></div>');
  assert.equal(f.step(), null); assert.deepEqual(f.clicked, []); f.close();
});
test('ignores navigation links, disabled, hidden, inert, transparent and offscreen choices', () => {
  const f=fixture(banner('<a href="/delete-account">Reject all</a><button disabled>Reject</button><button style="display:none">Decline</button><div hidden><button>Reject all</button></div><div style="opacity:0"><button>Reject</button></div><div inert><button>Reject all</button></div><button aria-disabled="true">Reject</button><button data-offscreen>Decline all</button>'));
  assert.equal(f.step(), null); assert.deepEqual(f.clicked, []); f.close();
});
test('does not submit an unknown form', () => {
  const f=fixture(banner('<form><button>Reject all</button></form>'));
  assert.equal(f.step(), null); f.close();
});
test('opens preferences, then rejects in the replacement panel', () => {
  const f=fixture(banner('<button id="manage">Manage preferences</button><button id="all">Accept all</button>'));
  f.w.document.getElementById('manage').onclick=()=>{
    f.w.document.body.innerHTML=banner('<button id="reject">Reject optional cookies</button><button>Accept all</button>');
  };
  assert.equal(f.step()?.kind, 'preferences');
  assert.equal(f.step()?.kind, 'reject');
  assert.deepEqual(f.clicked, ['manage','reject']); f.close();
});
test('does not repeatedly click an unresponsive control', () => {
  const f=fixture(banner('<button>Reject all</button>'));
  assert.equal(f.step()?.kind,'reject'); assert.equal(f.step(),null); assert.equal(f.clicked.length,1); f.close();
});
test('recognises known CMP roots even without English cookie text', () => {
  const f=fixture('<div id="onetrust-banner-sdk"><p>Your privacy matters</p><button id="reject">Reject all</button></div>');
  assert.equal(f.step()?.kind, 'reject'); assert.deepEqual(f.clicked,['reject']); f.close();
});
test('handles open shadow dialogs', () => {
  const f=fixture('<div id="shadow"></div>');
  f.w.document.getElementById('shadow').attachShadow({mode:'open'}).innerHTML=banner('<button id="safe">Necessary only</button>');
  assert.equal(f.step()?.kind,'reject'); f.close();
});
test('handles late banners and replacements', () => {
  const f=fixture('<h1>News</h1>'); assert.equal(f.step(),null);
  f.w.document.body.insertAdjacentHTML('beforeend',banner('<button>Reject all</button>'));
  assert.equal(f.step()?.kind,'reject'); f.close();
});
function cookiebot(extra='') {
  return '<div id="CybotCookiebotDialog"><p>Cookie preferences</p>'+
    ['Necessary','Preferences','Statistics','Marketing'].map((name,index)=>`<label><input type="checkbox" id="CybotCookiebotDialogBodyLevelButton${name}" checked ${index===0?'disabled':''}>${name}</label>`).join('')+
    extra+'<button id="save">Allow selection</button><button id="all">Accept all</button></div>';
}
test('turns off all three documented optional Cookiebot categories before saving', () => {
  const f=fixture(cookiebot()); let saved;
  f.w.document.getElementById('save').onclick=()=>{saved=[...f.w.document.querySelectorAll('input')].map(el=>el.checked);};
  assert.equal(f.step()?.kind,'disable'); assert.equal(f.step()?.kind,'disable'); assert.equal(f.step()?.kind,'disable');
  assert.equal(f.step()?.kind,'wait'); assert.equal(f.step()?.kind,'save');
  assert.deepEqual(saved,[true,false,false,false]); assert.ok(!f.clicked.includes('all')); f.close();
});
test('refuses Cookiebot auto-save when an extra vendor choice exists', () => {
  const f=fixture(cookiebot('<label><input type="checkbox" checked>Vendor legitimate interest</label>'));
  for(let i=0;i<5;i++) assert.equal(f.step(),null);
  assert.deepEqual(f.clicked,[]); f.close();
});
test('refuses auto-save on an unrecognised settings screen even with all visible switches off', () => {
  const f=fixture(banner('<label><input type="checkbox">Analytics</label><button>Save preferences</button>'));
  for(let i=0;i<3;i++) assert.equal(f.step(),null);
  assert.deepEqual(f.clicked,[]); f.close();
});
test('does not save if a hidden optional category remains enabled', () => {
  const f=fixture(cookiebot());
  f.w.document.getElementById('CybotCookiebotDialogBodyLevelButtonMarketing').closest('label').hidden=true;
  for(let i=0;i<5;i++)f.step();
  assert.ok(!f.clicked.includes('save')); f.close();
});
test('rechecks switches that change while waiting to save', () => {
  const f=fixture(cookiebot());
  [...f.w.document.querySelectorAll('input')].slice(1).forEach(el=>el.checked=false);
  assert.equal(f.step()?.kind,'wait');
  f.w.document.getElementById('CybotCookiebotDialogBodyLevelButtonMarketing').checked=true;
  assert.equal(f.step()?.kind,'disable'); assert.ok(!f.clicked.includes('save')); f.close();
});
