/* Optional: CHROMIUM_PATH=/path/to/chromium NODE_PATH=... node tests/chromium-smoke.cjs
   Real Chromium DOM/events/layout; Chrome extension APIs are mocked. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const http=require('node:http');
const {chromium}=require('playwright');
const ext=fs.existsSync(path.join(__dirname,'../engine.js'))?path.join(__dirname,'..'):path.join(__dirname,'../extension');
const engine=fs.readFileSync(path.join(ext,'engine.js'),'utf8');
const content=fs.readFileSync(path.join(ext,'content.js'),'utf8');
const wrap=body=>`<!doctype html><style>body{font:16px system-ui}section{position:fixed;bottom:20px;left:20px;padding:20px;background:#eee}button{padding:10px;margin:5px}</style><h1>Fixture page</h1>${body}`;
const banner=body=>`<section role="dialog"><p>We use cookies.</p>${body}</section>`;
const server=http.createServer((req,res)=>{
  const name=req.url.slice(1);
  if(['popup.html','popup.css','popup.js'].includes(name)||/^icons\/\d+\.png$/.test(name)){
    res.setHeader('Content-Type',name.endsWith('.css')?'text/css':name.endsWith('.js')?'text/javascript':name.endsWith('.png')?'image/png':'text/html');
    res.end(fs.readFileSync(path.join(ext,name)));return;
  }
  res.setHeader('Content-Type','text/html');res.end(wrap(''));
});
let checks=0;
async function main(){
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const origin='http://127.0.0.1:'+server.address().port;
  const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH,args:['--no-sandbox','--disable-gpu','--disable-dev-shm-usage']});
  try{
    const context=await browser.newContext({viewport:{width:1000,height:800}});
    const page=await context.newPage();
    async function setup(html){
      await page.goto(origin);await page.setContent(wrap(html));
      await page.evaluate(()=>{
        window.__events=[];window.__allowed=true;window.__changes=[];
        window.chrome={runtime:{sendMessage:async m=>{
          if(m.type==='canRun')return {allowed:window.__allowed};
          window.__events.push(m);return {ok:true};
        },onMessage:{addListener(){}}},storage:{onChanged:{addListener:fn=>window.__changes.push(fn)}}};
      });
      await page.addScriptTag({content:engine});await page.addScriptTag({content});
    }
    await setup(banner('<button id="accept">Accept all</button><button id="reject">Accept only necessary cookies</button>'));
    await page.evaluate(()=>{window.__clicked=[];document.querySelectorAll('button').forEach(el=>el.onclick=()=>{window.__clicked.push(el.id);el.closest('section').remove();});});
    await page.waitForFunction(()=>window.__events.some(e=>e.kind==='reject'));
    assert.deepEqual(await page.evaluate(()=>window.__clicked),['reject']);checks++;console.log('PASS actual layout: automatic necessary-only click');

    await setup(banner('<button id="manage">Manage preferences</button><button id="accept">Accept all</button>'));
    await page.evaluate(()=>{document.getElementById('manage').onclick=()=>{document.querySelector('section').innerHTML='<p>Cookie settings</p><button id="reject">Reject all</button><button id="accept">Accept all</button>';document.getElementById('reject').onclick=()=>document.querySelector('section').remove();};});
    await page.waitForFunction(()=>window.__events.some(e=>e.kind==='reject'));
    assert.deepEqual(await page.evaluate(()=>window.__events.map(e=>e.kind)),['preferences','reject']);checks++;console.log('PASS real automatic preferences → reject flow');

    await setup(banner('<button>Accept all</button><button>OK</button>'));
    await page.waitForTimeout(1400);assert.equal(await page.evaluate(()=>window.__events.length),0);checks++;console.log('PASS unsafe-only banner remains untouched');

    await setup('');await page.evaluate(()=>{window.__allowed=false;document.body.insertAdjacentHTML('beforeend','<section role="dialog"><p>We use cookies</p><button>Reject all</button></section>');});
    await page.waitForTimeout(1400);assert.equal(await page.evaluate(()=>window.__events.length),0);
    await page.evaluate(()=>{window.__allowed=true;window.__changes.forEach(fn=>fn({settings:{newValue:{enabled:true}}},'local'));});
    await page.waitForFunction(()=>window.__events.some(e=>e.kind==='reject'));checks++;console.log('PASS paused pages stay untouched; resume activates late banner');

    await setup(banner('<button id="hidden" style="display:none">Reject all</button><button id="accept">Accept all</button>'));
    await page.waitForTimeout(1300);assert.equal(await page.evaluate(()=>window.__events.length),0);
    await page.evaluate(()=>document.getElementById('hidden').style.display='block');
    await page.waitForFunction(()=>window.__events.some(e=>e.kind==='reject'));checks++;console.log('PASS CSS-hidden choice waits until visible');

    await setup('<div id="host"></div>');
    await page.evaluate(()=>{document.getElementById('host').attachShadow({mode:'open'}).innerHTML='<section role="dialog"><p>Cookies</p><button id="safe">Reject all</button></section>';});
    await page.waitForFunction(()=>window.__events.some(e=>e.kind==='reject'));checks++;console.log('PASS real shadow-root banner');

    const bot='<div id="CybotCookiebotDialog" style="position:fixed;inset:50px"><p>Cookie settings</p>'+['Necessary','Preferences','Statistics','Marketing'].map((name,i)=>`<label style="display:block"><input type="checkbox" id="CybotCookiebotDialogBodyLevelButton${name}" checked ${i===0?'disabled':''}>${name}</label>`).join('')+'<button id="save">Allow selection</button><button id="all">Accept all</button></div>';
    await setup(bot);
    await page.evaluate(()=>{window.__saved=null;document.getElementById('save').onclick=()=>{window.__saved=[...document.querySelectorAll('input')].map(el=>el.checked);document.getElementById('CybotCookiebotDialog').remove();};});
    await page.waitForFunction(()=>window.__saved!==null);
    assert.deepEqual(await page.evaluate(()=>window.__saved),[true,false,false,false]);checks++;console.log('PASS real native checkbox events disable all optionals before saving');

    await page.goto(origin);
    await page.setContent(wrap('<iframe id="frame" style="display:none" src="'+origin+'/frame"></iframe>'));
    const frame=page.frames().find(f=>f!==page.mainFrame());await frame.waitForLoadState();
    await frame.setContent(wrap(banner('<button>Reject all</button>')));
    await frame.evaluate(()=>{window.__events=[];window.chrome={runtime:{sendMessage:async m=>m.type==='canRun'?{allowed:true}:(window.__events.push(m),{ok:true}),onMessage:{addListener(){}}},storage:{onChanged:{addListener(){}}}};});
    await frame.addScriptTag({content:engine});await frame.addScriptTag({content});
    await page.waitForTimeout(1400);assert.equal(await frame.evaluate(()=>window.__events.length),0);checks++;console.log('PASS hidden iframe stays untouched');
    await page.evaluate(()=>{const f=document.getElementById('frame');f.style.cssText='width:800px;height:400px';});
    await frame.waitForFunction(()=>window.__events.some(e=>e.kind==='reject'));checks++;console.log('PASS visible consent iframe becomes active');

    const popup=await context.newPage();
    await popup.addInitScript(()=>{
      const cfg={enabled:true,excludedHosts:[]};
      window.chrome={runtime:{sendMessage:async m=>{
        if(m.type==='getPopup')return {settings:cfg,host:'news.example',tabId:7,event:null};
        if(m.type==='setEnabled')cfg.enabled=m.value;
        if(m.type==='setSite')cfg.excludedHosts=m.value?[]:['news.example'];
        return {ok:true};
      }},tabs:{sendMessage:async()=>({scheduled:true})}};
    });
    await popup.setViewportSize({width:360,height:700});await popup.goto(origin+'/popup.html');
    await popup.waitForFunction(()=>!document.getElementById('enabled').disabled);
    assert.equal(await popup.locator('#enabled').isChecked(),true);
    await popup.locator('#enabled').uncheck();await popup.waitForFunction(()=>document.getElementById('scan').disabled);
    await popup.locator('#enabled').check();await popup.locator('#site').uncheck();
    await popup.waitForFunction(()=>document.getElementById('scan').disabled);
    await popup.locator('#site').check();await popup.locator('#scan').click();
    assert.match(await popup.locator('#message').textContent(),/Checking again/);
    assert.equal(await popup.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
    await popup.screenshot({path:process.env.POPUP_SCREENSHOT||'popup-check.png',fullPage:true});
    checks++;console.log('PASS popup rendering, global/site controls, rescan, and width');
    console.log(`Chromium smoke checks passed: ${checks}`);
  }finally{await browser.close();server.close();}
}
main().catch(error=>{console.error(error);server.close();process.exit(1);});
