# Just Enough — Necessary Cookies Only

Chrome extension for Thomas / Hasbreo. Version 1.0.0.

## Install on your Windows PC

1. Right-click **Just-Enough-v1.0.0.zip** and choose **Extract All**.
2. Keep the extracted **Just-Enough** folder somewhere permanent (for example, Documents). Chrome loads the files from there.
3. Type **chrome://extensions** into Chrome's address bar.
4. Switch on **Developer mode** at the top right.
5. Click **Load unpacked** and select the **Just-Enough** folder containing **manifest.json**. Choose the extracted folder, not the ZIP.
6. Open Chrome's puzzle-piece Extensions menu and pin **Just Enough** if you want its controls handy.
7. Refresh any websites that were already open. It starts automatically on new pages.

No build, account, subscription, server, or npm install is needed to use the extension.

## What it does

- Chooses clear English-language options such as **Reject all**, **Reject optional cookies**, **Necessary cookies only**, and **Continue without accepting** within detected cookie banners.
- Opens recognised **Manage preferences** or **Cookie settings** controls when needed, then looks for an explicit rejection or necessary-only option.
- Recognises a range of common consent-container layouts, including OneTrust, Cookiebot, Didomi, Quantcast, CookieYes, Complianz, Iubenda, and Usercentrics. A recognised layout is not a guarantee that a particular site is supported.
- Handles late-loading banners, ordinary consent frames, and accessible open shadow components.
- For the documented, complete four-checkbox Cookiebot layout only, turns off Preferences, Statistics, and Marketing before clicking an explicit save-selection control. Other preference panels need a clear reject/necessary-only action; it does not guess at hidden vendor or legitimate-interest settings.
- Provides a global on/off switch, an exception for the current hostname, and a **Check this page again** button.

The toolbar check mark means it clicked a reject/save-selection option. It does not independently audit the website's resulting cookies or compliance.

## Limits

- This is a first version. Cookie banners vary enormously, so some will still need a manual click. English labels are supported; unknown languages and unclear options stay manual.
- It never deliberately clicks **Accept all**, a plain **Accept**, **Agree**, **OK**, a close icon, a paid refusal option, or a generic save button on an unknown settings panel.
- It does not remove banners with CSS. The website receives the real click and is responsible for saving your choice.
- It does not undo a previous acceptance, delete cookies, stop scripts already loaded, or block tracking by itself.
- It cannot run on Chrome's internal pages or other browser-protected pages. Closed shadow components and inaccessible/sandboxed frames may need manual handling.
- A site exception applies to that exact hostname, including cookie banners in its frames. Other subdomains are separate.
- Clicking while paused does not reverse any choice already made. Use the website's own cookie settings to change earlier choices.
- Locally installed extensions update manually. To update, replace the files in this same folder, click the extension's reload icon on **chrome://extensions**, then refresh your website tabs.

## Privacy and permissions

All logic is bundled. There are no network requests, analytics, remote scripts, accounts, or external services in this extension.

Chrome grants the extension access to ordinary HTTP/HTTPS sites so it can inspect cookie-banner controls and click the appropriate choice. These site permissions also let it check the current site's hostname so site exceptions work in consent frames. `storage` saves your on/off setting and exact hostname exceptions locally. It does not request Chrome's cookies, history, passwords, or downloads APIs.

The extension stores only its settings permanently. A tab's latest action kind and timestamp are kept in browser-session storage for the popup, and removed when the tab closes or navigates. No page text, URLs, browsing history, or consent strings are retained by the extension.

## Verification

The package includes the readable extension source and automated tests. The tests cover rejection versus acceptance, unrelated controls, visibility guards, delayed and shadow banners, two-step preference flows, the Cookiebot four-category path, settings changes, and frame permission checks. Simulated-layout DOM tests are distinct from real-browser checks; see **TEST-RESULTS.txt** for the final run.

## References

- Chrome installation: https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world#load-unpacked
- Chrome content scripts: https://developer.chrome.com/docs/extensions/reference/manifest/content-scripts
- Chrome storage: https://developer.chrome.com/docs/extensions/reference/api/storage
- Cookiebot category/submit controls: https://support.cookiebot.com/hc/en-us/articles/360003921454

