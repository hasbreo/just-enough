'use strict';
const defaults = {enabled: true, excludedHosts: []};
const validUrl = value => { try { const url = new URL(value); return /^https?:$/.test(url.protocol) ? url : null; } catch { return null; } };
const settings = async () => ({...defaults, ...(await chrome.storage.local.get('settings')).settings});
let writes = Promise.resolve();
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  const handle = async () => {
    const cfg = await settings();
    const topUrl = validUrl(sender.tab?.url);
    if (message.type === 'canRun') return {allowed: !!(topUrl && cfg.enabled && !cfg.excludedHosts.includes(topUrl.hostname))};
    if (message.type === 'recordAction') {
      if (!topUrl || !cfg.enabled || cfg.excludedHosts.includes(topUrl.hostname)) return {ok: false};
      if (!['reject', 'save', 'preferences', 'disable'].includes(message.kind)) return {ok: false};
      // Session storage only: the latest attempt per tab, discarded when the browser restarts.
      const event = {kind: message.kind, at: Date.now()};
      await chrome.storage.session.set({['tab:' + sender.tab.id]: event});
      const final = message.kind === 'reject' || message.kind === 'save';
      await chrome.action.setBadgeText({tabId: sender.tab.id, text: final ? '✓' : '…'});
      await chrome.action.setBadgeBackgroundColor({tabId: sender.tab.id, color: '#087c61'});
      return {ok: true};
    }
    // Settings are writable only by this extension's pages, never by a content script.
    if (sender.tab || !sender.url?.startsWith(chrome.runtime.getURL(''))) return {error: 'Not allowed'};
    if (message.type === 'getPopup') {
      const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
      const url = validUrl(tab?.url);
      const event = tab?.id ? (await chrome.storage.session.get('tab:' + tab.id))['tab:' + tab.id] : null;
      return {settings: cfg, host: url?.hostname || null, tabId: tab?.id, event};
    }
    if (message.type === 'setEnabled' && typeof message.value === 'boolean') {
      cfg.enabled = message.value;
      await chrome.storage.local.set({settings: cfg});
      return {ok: true};
    }
    if (message.type === 'setSite' && typeof message.value === 'boolean') {
      const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
      const url = validUrl(tab?.url);
      if (!url) return {error: 'This tab cannot be changed.'};
      cfg.excludedHosts = cfg.excludedHosts.filter(host => host !== url.hostname);
      if (!message.value) cfg.excludedHosts.push(url.hostname);
      await chrome.storage.local.set({settings: cfg});
      return {ok: true};
    }
    return {error: 'Unknown request'};
  };
  // Serialize read-modify-write operations, including fast consecutive popup changes.
  const job = writes.then(handle);
  writes = job.catch(() => {});
  job.then(reply, () => reply({error: 'Could not update extension. Try reopening the popup.'}));
  return true;
});
chrome.tabs.onRemoved.addListener(tabId => { chrome.storage.session.remove('tab:' + tabId); });
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (change.status === 'loading') {
    chrome.storage.session.remove('tab:' + tabId);
    chrome.action.setBadgeText({tabId, text: ''});
  }
});
