'use strict';
const $ = id => document.getElementById(id);
let state;
const request = message => chrome.runtime.sendMessage(message);
async function refresh() {
  state = await request({type: 'getPopup'});
  if (state.error) throw new Error(state.error);
  $('enabled').disabled = false;
  $('enabled').checked = state.settings.enabled;
  $('host').textContent = state.host || 'Unavailable on this tab';
  $('site').checked = !!state.host && !state.settings.excludedHosts.includes(state.host);
  $('site').disabled = !state.host;
  const allowed = state.host && state.settings.enabled && $('site').checked;
  $('scan').disabled = !allowed;
  $('dot').classList.toggle('off', !allowed);
  let status = !state.host ? 'Open a website to use Just Enough.' : !allowed ? 'Paused here. You’re in control.' : 'Watching for cookie banners.';
  if (allowed && state.event) status = ['reject', 'save'].includes(state.event.kind)
    ? 'A necessary-only choice was clicked on this tab.' : 'Working through cookie preferences…';
  $('status').textContent = status;
}
async function update(message) {
  try {
    $('message').textContent = '';
    const result = await request(message);
    if (result.error) throw new Error(result.error);
    await refresh();
  } catch (error) { $('message').textContent = error.message; }
}
$('enabled').addEventListener('change', () => update({type: 'setEnabled', value: $('enabled').checked}));
$('site').addEventListener('change', () => update({type: 'setSite', value: $('site').checked}));
$('scan').addEventListener('click', async () => {
  try {
    await chrome.tabs.sendMessage(state.tabId, {type: 'rescan'});
    $('message').textContent = 'Checking again. If it stays, choose manually.';
  } catch { $('message').textContent = 'Refresh this page once, then try again.'; }
});
refresh().catch(() => { $('status').textContent = 'Reopen the extension to try again.'; });
