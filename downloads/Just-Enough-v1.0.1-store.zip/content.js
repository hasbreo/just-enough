(() => {
  'use strict';
  const engine = new JustEnough.Engine();
  let timer, running = false, enabled = true, actions = 0;
  let lastScan = 0;
  let inView = window === window.top;
  let locationKey = location.href;
  const send = message => chrome.runtime.sendMessage(message).catch(() => null);
  function schedule(delay = 800) {
    if (!enabled || document.hidden || !inView || timer || actions >= 18) return;
    timer = setTimeout(() => { timer = null; scan(); }, Math.max(delay, 1000 - (Date.now() - lastScan)));
  }
  async function scan() {
    if (running || document.hidden || !inView || !enabled || actions >= 18) return;
    running = true;
    lastScan = Date.now();
    try {
      const state = await send({type: 'canRun'});
      if (!state?.allowed) { enabled = false; return; }
      const action = engine.next();
      if (action?.kind === 'wait') { schedule(800); return; }
      if (!action) return;
      // Recheck after DOM evaluation, and recompute the proposed action. User switches win.
      const check = await send({type: 'canRun'});
      if (!check?.allowed || !enabled || document.hidden || !inView) return;
      const fresh = engine.next();
      if (!fresh || fresh.kind !== action.kind || fresh.element !== action.element) { schedule(); return; }
      if (engine.perform(fresh)) {
        actions++;
        await send({type: 'recordAction', kind: fresh.kind, label: fresh.label});
        schedule();
      }
    } catch { /* An extension update or an unsupported document should not disturb the page. */ }
    finally { running = false; }
  }
  const observer = new MutationObserver(changes => {
    if (changes.some(c => c.type === 'childList' || c.type === 'attributes' || c.type === 'characterData')) schedule();
  });
  const observed = new WeakSet();
  function observe(root) {
    if (observed.has(root)) return;
    observed.add(root);
    observer.observe(root, {childList: true, subtree: true, characterData: true, attributes: true,
      attributeFilter: ['class', 'style', 'hidden', 'open', 'aria-hidden', 'aria-checked', 'checked', 'disabled']});
  }
  observe(document.documentElement);
  if (window !== window.top) {
    new IntersectionObserver(entries => {
      inView = entries.some(entry => entry.isIntersecting);
      if (inView) schedule();
    }).observe(document.documentElement);
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.settings) {
      enabled = true;
      if (timer) { clearTimeout(timer); timer = null; }
      schedule(100);
    }
  });
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (message.type !== 'rescan') return;
    enabled = true;
    actions = 0;
    schedule(100);
    reply({scheduled: true});
  });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) schedule(); });
  document.addEventListener('click', () => schedule(), {passive: true});
  document.addEventListener('change', () => schedule(), {passive: true});
  // Low-frequency fallback for shadow components, SPA routes, and property-only UI changes.
  setInterval(() => {
    if (document.hidden || !enabled) return;
    if (locationKey !== location.href) { locationKey = location.href; actions = 0; }
    for (const el of document.querySelectorAll('*')) if (el.shadowRoot) observe(el.shadowRoot);
    schedule();
  }, 5000);
  schedule(150);
})();
