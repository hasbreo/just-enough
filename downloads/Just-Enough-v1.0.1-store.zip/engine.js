/* Local DOM-only consent helper. No remote code or cookie deletion. */
(() => {
  'use strict';
  const normal = value => String(value || '').normalize('NFKC').toLowerCase()
    .replace(/[’‘]/g, "'").replace(/[^\p{L}\p{N}'\s]/gu, ' ').replace(/\s+/g, ' ').trim();
  const label = el => normal(el.innerText || el.value || el.textContent || el.getAttribute('aria-label'));
  const cookieWords = /\b(cookies?|tracking technologies|consent preferences|storage preferences)\b/i;
  const known = [
    '#onetrust-banner-sdk', '#onetrust-pc-sdk', '#CybotCookiebotDialog',
    '#didomi-notice', '#didomi-popup', '.didomi-popup-container',
    '#qc-cmp2-ui', '#truste-consent-track', '#truste-consent-content',
    '#usercentrics-root', '#usercentrics-cmp-ui', '#uc-center-container',
    '#consent-manager', '#axeptio_overlay', '#cmplz-cookiebanner-container',
    '.cmplz-cookiebanner', '#cky-consent', '.cky-consent-container', '.cky-modal',
    '#cookie-law-info-bar', '#cookie-notice', '#moove_gdpr_cookie_info_bar',
    '#moove_gdpr_cookie_modal', '#iubenda-cs-banner', '#iubenda-cs-preferences',
    '#sp_message_container', '[id^="sp_message_container_"]',
    '#CookieConsent', '#CookieConsentDialog', '#tarteaucitronRoot'
  ].join(',');
  const generic = '[role="dialog"],dialog,[aria-modal="true"],[id*="cookie" i],[class*="cookie-banner" i],[class*="cookie-consent" i],[class*="consent-modal" i],[class*="consent-banner" i]';
  const controls = 'button,[role="button"],input[type="button"],input[type="submit"],a';
  const direct = new Set([
    'reject', 'reject all', 'reject all cookies', 'reject cookies', 'reject optional',
    'reject optional cookies', 'reject non essential', 'reject non essential cookies',
    'reject all non essential', 'reject all non essential cookies', 'reject all optional cookies',
    'decline', 'decline all', 'decline cookies', 'decline optional cookies',
    'deny', 'deny all', 'deny cookies', 'deny optional cookies', 'refuse all',
    'necessary only', 'only necessary', 'necessary cookies only', 'only necessary cookies',
    'accept necessary', 'accept necessary cookies', 'accept necessary only',
    'accept necessary cookies only', 'accept only necessary cookies', 'accept only necessary',
    'allow necessary cookies only', 'allow only necessary cookies', 'allow necessary only',
    'use necessary cookies only', 'essential only', 'only essential', 'essential cookies only',
    'only essential cookies', 'accept essential cookies only', 'accept essential only',
    'accept only essential cookies', 'accept only essential', 'allow essential only',
    'allow only essential cookies', 'use essential cookies only', 'strictly necessary only',
    'continue without accepting', 'continue without agreeing', 'continue without consent',
    'continue without accepting cookies', 'do not accept', 'do not consent', 'no thanks'
  ]);
  const preferences = new Set([
    'manage preferences', 'manage cookie preferences', 'cookie preferences',
    'manage cookies', 'manage cookie settings', 'cookie settings', 'cookies settings',
    'customize', 'customise', 'customize cookies', 'customise cookies',
    'customize settings', 'customise settings', 'customize preferences',
    'customise preferences', 'settings', 'preferences', 'more options',
    'show preferences', 'change settings', 'adjust settings', 'manage options'
  ]);
  const saveLabels = new Set([
    'save preferences', 'save my preferences', 'save cookie preferences', 'save settings',
    'save my choices', 'save choices', 'confirm choices', 'confirm my choices',
    'confirm selection', 'confirm preferences', 'accept selected', 'accept selection',
    'allow selection', 'allow selected', 'use selected cookies', 'save and close'
  ]);

  function parent(el) { return el.parentElement || el.getRootNode()?.host || null; }
  function visible(el) {
    if (!el || !el.isConnected || !el.getClientRects().length) return false;
    for (let node = el; node && node.nodeType === 1; node = parent(node)) {
      const style = getComputedStyle(node);
      if (node.hidden || node.getAttribute('aria-hidden') === 'true' || node.inert || node.hasAttribute('inert') ||
          style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
    }
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
  }
  function clickable(el) {
    if (!visible(el) || el.disabled || el.getAttribute('aria-disabled') === 'true') return false;
    // Never follow a policy, subscription, or other navigation link.
    if (el.tagName === 'A' && el.getAttribute('href') && !el.getAttribute('href').startsWith('#')) return false;
    if (el.closest('form') && !el.closest(known) && (el.type === 'submit' || (el.tagName === 'BUTTON' && !el.hasAttribute('type')))) return false;
    return true;
  }
  function roots() {
    const result = [document];
    // Open shadow roots only; never bypass closed components.
    for (let i = 0; i < result.length && result.length < 40; i++) {
      const walker = document.createTreeWalker(result[i], NodeFilter.SHOW_ELEMENT);
      let node, visits = 0;
      while ((node = walker.nextNode()) && ++visits < 12000) {
        if (node.shadowRoot && result.length < 40) result.push(node.shadowRoot);
      }
    }
    return result;
  }
  function containers(allRoots) {
    const result = [];
    const add = (el, trusted) => {
      if (!visible(el) || el === document.body || el === document.documentElement) return;
      const text = el.innerText || el.textContent || '';
      if (text.length > 24000 || (!trusted && !cookieWords.test(text))) return;
      if (!trusted) {
        const style = getComputedStyle(el);
        const isDialog = el.matches('[role="dialog"],dialog,[aria-modal="true"]');
        const isBanner = ['fixed', 'sticky'].includes(style.position);
        if (!isDialog && !isBanner) return;
      }
      if (!result.includes(el)) result.push(el);
    };
    for (const root of allRoots) {
      root.querySelectorAll(known).forEach(el => add(el, true));
      root.querySelectorAll(generic).forEach(el => add(el, false));
      // A CMP shadow host often wraps the actual dialog inside its root.
      if (root.host?.matches(known)) root.querySelectorAll('[role="dialog"],dialog,section,main').forEach(el => add(el, true));
    }
    return result;
  }
  function buttons(container) {
    const found = [...container.querySelectorAll(controls)];
    for (const el of container.querySelectorAll('*')) {
      if (el.shadowRoot) found.push(...buttons(el.shadowRoot));
    }
    return found.filter(clickable);
  }
  function toggles(container) {
    // Only the documented four-category Cookiebot schema is eligible for auto-save.
    // Generic settings can hide vendor/legitimate-interest choices: leave those manual.
    if (container.id !== 'CybotCookiebotDialog') return [];
    const categories = ['Necessary', 'Preferences', 'Statistics', 'Marketing'];
    const expected = categories.map(name => container.querySelector('#CybotCookiebotDialogBodyLevelButton' + name));
    if (expected.some(el => !el?.matches('input[type="checkbox"]'))) return [];
    const all = [...container.querySelectorAll('input[type="checkbox"],input[type="radio"],[role="switch"],[role="checkbox"],select,[role="combobox"]')];
    if (all.length !== 4 || all.some(el => !expected.includes(el)) || [...container.querySelectorAll('*')].some(el => el.shadowRoot)) return [];
    return expected.map((el, index) => ({el, kind: index ? 'optional' : 'required', state: el.checked}));
  }
  class Engine {
    constructor() {
      this.clicked = new WeakMap();
      this.opened = new WeakSet();
      this.panelState = new WeakMap();
      this.lastActionAt = 0;
    }
    next() {
      if (Date.now() - this.lastActionAt < 650) return null;
      const scopes = containers(roots());
      for (const container of scopes) {
        const available = buttons(container);
        const reject = available.find(el => direct.has(label(el)) && this.canClick(el));
        if (reject) return {kind: 'reject', element: reject, container, label: label(reject)};
      }
      for (const container of scopes) {
        const available = buttons(container);
        const save = available.find(el => saveLabels.has(label(el)) && this.canClick(el));
        const switches = toggles(container);
        if (save && switches.length && switches.every(s => s.kind !== 'unknown' && s.state !== null)) {
          const optionals = switches.filter(s => s.kind === 'optional');
          const requireds = switches.filter(s => s.kind === 'required');
          // Require an actual optional group; missing or unrecognised controls stay manual.
          const disabledOptional = optionals.some(s => s.state && (s.el.disabled || s.el.getAttribute('aria-disabled') === 'true'));
          if (optionals.length && !disabledOptional && requireds.every(s => s.state === true)) {
            const enabled = optionals.find(s => s.state);
            if (enabled) {
              const target = visible(enabled.el) ? enabled.el : [...(enabled.el.labels || [])].find(visible);
              if (target && this.canClick(target)) return {kind: 'disable', element: target, container, label: 'optional cookie switch'};
            } else {
              // Two scans separated by time catch UI updates before committing preferences.
              const fingerprint = switches.map(s => s.kind + ':' + s.state).join('|');
              const previous = this.panelState.get(container);
              if (previous?.fingerprint === fingerprint && Date.now() - previous.at >= 700) {
                return {kind: 'save', element: save, container, label: label(save)};
              }
              if (!previous || previous.fingerprint !== fingerprint) this.panelState.set(container, {fingerprint, at: Date.now()});
              return {kind: 'wait'};
            }
          }
        }
        const manage = available.find(el => preferences.has(label(el)) && !this.opened.has(el) && this.canClick(el));
        if (manage) return {kind: 'preferences', element: manage, container, label: label(manage)};
      }
      return null;
    }
    canClick(el) { return !this.clicked.has(el); }
    perform(action) {
      if (!action?.element || !clickable(action.element) || !this.canClick(action.element)) return false;
      this.clicked.set(action.element, true);
      this.lastActionAt = Date.now();
      if (action.kind === 'preferences') this.opened.add(action.element);
      action.element.click();
      return true;
    }
  }
  globalThis.JustEnough = {Engine};
})();
